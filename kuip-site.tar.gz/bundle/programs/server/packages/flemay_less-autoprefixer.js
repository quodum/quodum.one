(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/flemay_less-autoprefixer/packages/flemay_less-autoprefix //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['flemay:less-autoprefixer'] = {};

})();

//# sourceMappingURL=flemay_less-autoprefixer.js.map
